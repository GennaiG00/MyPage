Progetto per Laboratorio di Programmazione.
Semplice struttura per simulare un utente con un account il quale può prelevare, aggiungere e 
trasferire soldi dal suo account a quello di un altro utente tramite IBAN.
