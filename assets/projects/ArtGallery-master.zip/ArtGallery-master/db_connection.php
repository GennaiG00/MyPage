<?php

include "dbConnectionClass.php";

if($_POST['fname']) {

    $fname = $_POST['fname'];
    $iname = $_POST['iname'];
    $gender = $_POST['gender'];
    $age = $_POST['age'];
    $sentiment = $_POST['sentiment'];

    $mysqli = new db('localhost', 'artgallery', 'artgallery', 'artgallery');

    $sql = "SELECT * FROM gallery";

    $result = $mysqli->query($sql)->fetchAll();

    $autoIncrement = (count($result));

    $mysqli->query("ALTER TABLE `gallery` AUTO_INCREMENT=$autoIncrement");

    $mysqli->query("INSERT INTO `gallery` (`image`, `name`, `gender`, `age`, `sentiment`) VALUES ('$fname', '$iname', '$gender', '$age', '$sentiment')");
}

?>
