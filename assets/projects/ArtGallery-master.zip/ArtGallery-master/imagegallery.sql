-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Creato il: Dic 27, 2022 alle 17:18
-- Versione del server: 10.4.25-MariaDB
-- Versione PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `artgallery`
--

-- --------------------------------------------------------

--
-- Struttura della tabella `imagegallery`
--

CREATE TABLE `imagegallery` (
  `id` int(10) NOT NULL,
  `image` varchar(70) NOT NULL,
  `name` varchar(70) NOT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `sentiment` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dump dei dati per la tabella `imagegallery`
--

INSERT INTO `imagegallery` (`id`, `image`, `name`, `gender`, `age`, `sentiment`) VALUES
(0, 'anziana_arrabbiata.webp', 'Anaziana arrabbiata', 'male', 83, 'sad'),
(1, 'anziano.webp', 'Anziano', 'female', 66, 'sad'),
(2, 'bambina_arrabbiata.webp', 'Bambina Arrabbiata', 'female', 22, 'neutral'),
(3, 'bambina_felice.webp', 'Bambina Felice', 'male', 1, 'happy'),
(4, 'bambino_arrabbiato.webp', 'Bambino Arrabbiato', 'male', 43, 'angry'),
(5, 'bambino_felice.webp', 'Bambino Felice', 'male', 8, 'happy'),
(6, 'johnny_stecchino.webp', 'Johnny Stecchino', 'male', 26, 'neutral'),
(7, 'dama_con_ermellino.webp', 'Dama con ermellino', 'female', 29, 'neutral'),
(8, 'david.webp', 'David ', 'male', 25, 'neutral'),
(9, 'dwight_shrute.webp', 'Dwight Shrute', 'male', 45, 'neutral'),
(10, 'fantocci_stupito.webp', 'Ragionier Ugo Fantocci', 'male', 64, 'fearful'),
(11, 'felicità_astratta.webp', 'Felicità astratta', 'male', 62, 'fearful'),
(12, 'felicita_checco_zalone.webp', 'Checco Zalone', 'male', 40, 'neutral'),
(13, 'gioconda.webp', 'Gioconda', 'female', 27, 'neutral'),
(14, 'jimi_hendrix.webp', 'Jimi Hendrix', 'male', 24, 'neutral'),
(15, 'keith_richards.webp', 'Keit Richards', 'male', 56, 'neutral'),
(16, 'margherita_hack.webp', 'Margherita Hack', 'female', 82, 'happy'),
(17, 'mr_gioconda.webp', 'Mr. Gioconda', 'male', 54, 'happy'),
(18, 'papa_francesco.webp', 'Papa Francesco', 'male', 53, 'happy'),
(19, 'rabbia_donna_animale.webp', 'Rabbia Donna', 'male', 27, 'sad'),
(20, 'rabbia_work_art.webp', 'Rabbia work art', '', 0, ''),
(21, 'ragazza_col_turbante.webp', 'Ragazza col turbante', 'male', 37, 'neutral'),
(22, 'risata_di_felicità.webp', 'Risata di un ragazzo', '', 0, ''),
(23, 'rocky_balboa.webp', 'Rocky Balboa', 'male', 38, 'happy'),
(24, 'scimmia_che_ride.webp', 'Scimmia che ride', 'male', 51, 'neutral'),
(25, 'stupore_astratto.webp', 'Stupore astratto', '', 0, ''),
(26, 'tristezza_astratta.webp', 'Tristezza astratta', '', 0, ''),
(27, 'urlo_di_munch.webp', 'Urlo di Munch', 'male', 73, 'surprised'),
(28, 'van_gogh.webp', 'Van Gogh', 'male', 59, 'neutral');

--
-- Indici per le tabelle scaricate
--

--
-- Indici per le tabelle `imagegallery`
--
ALTER TABLE `imagegallery`
  ADD PRIMARY KEY (`id`) NOT NULL AUTO_INCREMENT,
  ADD UNIQUE KEY `image` (`image`),
  ADD UNIQUE KEY `name` (`name`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
