<!DOCTYPE html>
<html lang="en">
<head>
    <title>ArtGallery</title>
    <link rel="stylesheet" href="CSS/styleWebcamMode.css" type="text/css">
    <link rel="stylesheet" href="CSS/generalStyle.css" type="text/css">
    <meta charset="UTF-8">
    <meta name="author" content="Gian Maria Gennai">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="faceApi/javascript/face-api.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils@0.1/camera_utils.js"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/control_utils@0.1/control_utils.js"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils@0.2/drawing_utils.js"
            crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.1/hands.js" crossorigin="anonymous"></script>
    <script src="JS/JSWebcamMode.js"></script>
</head>
<body>
<canvas id="output_canvas"></canvas>
<div id="main-class">
    <div id="header">
        <div id="title">
            <a href="index.html"><img id="title-image" src="image/logo-Model.webp"></a>
        </div>
    </div>
    <div id="primary-main">
        <h3>Choose your search method with the toggle switch button.</h3>
        <div id="toggle-switch">
            <label id="switch">
                <input type="checkbox" checked="checked">
                <button id="slider" onclick="toggleSwitch()"></button>
            </label>
        </div>
        <p>This is <span id="span-text-mode">Webcam Mode</span>, place you face in front of the webcam and wait the
            result.</p>
    </div>
    <div id="container">
        <div id="left-side-body">
            <div id="webcam">
                <div id="webcam-start-stop">
                    <img id="start-webcam" src="./image/webcam-off.webp" alt="webcam off" onclick="onOffWebcam()">
                </div>
                <div id="result-container">
                    <p id="gender">GENDER</p>
                    <p id="age">AGE</p>
                    <p id="sentiment">SENTIMENT</p>
                </div>
                <div id="display-video">
                    <video id="video"></video>
                    <canvas id="video-canvas"></canvas>
                </div>
            </div>
            <div id="search">
                <button id="search-button">Search</button>
            </div>
        </div>
        <div id="right-side-body">
            <?php
            include "dbConnectionClass.php";
            $mysqli = new db('localhost', 'artgallery', 'artgallery', 'artgallery');
            $sql = "SELECT * FROM gallery";
            $resultTmp = $mysqli->query($sql)->fetchAll();
            for($j=0; $j<count($resultTmp); $j++){
                $result[$j+1] = $resultTmp[$j];
            }
            $numberOfTableRow = (count($result))+1;
            $numberOfGridRow = floor($numberOfTableRow / 4);
            $remainderNumber = $numberOfTableRow % 4;
            $i = 1;
            $a = 0;
            $b = 0;
            $c = 0;
            if ($remainderNumber === 1) {
                $a = 1;
            } elseif ($remainderNumber === 2) {
                $a = 1;
                $b = 1;
            } elseif ($remainderNumber === 3) {
                $a = 1;
                $b = 1;
                $c = 1;
            }
            ?>
            <div id="box-image">
                <div id="row">
                    <div class="column" id="first-column">
                        <?php
                        for (; $i <= $numberOfGridRow + $a; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="column" id="second-column">
                        <?php
                        for (; $i <= ($numberOfGridRow * 2) + $a + $b; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="column" id="third-column">
                        <?php
                        for (; $i <= ($numberOfGridRow * 3) + $a + $b + $c; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="column" id="fourth-column">
                        <?php
                        for (; $i < ($numberOfGridRow * 4) + $a + $b + $c; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div id="load-image">
                <button id="load-image-button" onclick="document.location.href = 'loadNewImage.php'">New Image</button>
            </div>
        </div>
    </div>
</div>
<?php

include "footer.html";

?>
</body>
</html>