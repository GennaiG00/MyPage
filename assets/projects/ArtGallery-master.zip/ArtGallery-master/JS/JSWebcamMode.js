
/*start INITIALIZE*/
var video;
var canvas;
var canvasContext;
var hands;
var toggleSwitchButton;
var onOffWebCamButton;
var camera;
var searchButton;
var positionCanvas;
var positionToggleSwitchButton;
var positionOnOffWebcamButton;
var positionSearchButton;

var imageData = [];

class Image {
    constructor(gender, age, sentiment) {
        this.gender = gender;
        this.age = age
        this.sentiment = sentiment;
    }
}

function newImage(id, gender, age, sentiment) {
    imageData[id] = new Image(gender, age, sentiment);
}


$(document).ready(() => {
    $(this).scrollTop(0);
    video = document.getElementById('video');
    canvas = document.getElementById('output_canvas');
    canvasContext = canvas.getContext('2d');
    toggleSwitchButton = document.getElementById('switch');
    onOffWebCamButton = document.getElementById('start-webcam');
    searchButton = document.getElementById('search-button');

    hands = new Hands({
        locateFile: (file) => {
            return `https://cdn.jsdelivr.net/npm/@mediapipe/hands@0.1/${file}`;
        }
    });
    hands.setOptions({
        maxNumHands: 1,
        modelComplexity: 1,
        minDetectionConfidence: 0.5,
        minTrackingConfidence: 0.5
    });

    camera = new Camera(video, {
        onFrame: async () => {
            await hands.send({image: video});
        },
        width: 568,
        height: 400
    });

    updatePosition();
})

function updatePosition() {
    positionCanvas = canvas.getBoundingClientRect();
    positionToggleSwitchButton = toggleSwitchButton.getBoundingClientRect();
    positionOnOffWebcamButton = onOffWebCamButton.getBoundingClientRect();
    positionSearchButton = searchButton.getBoundingClientRect();
}


/*end INITIALIZE*/

/*start TOGGLE SWITCH BUTTON*/
function toggleSwitch() {
    if (document.getElementById("slider")) {
        document.location.href = 'manualMode.php';
    }
}

/*end TOGGLE SWITCH BUTTON*/

/*start LEFT SIDE*/

function onOffWebcam() {
    let genderDiv = document.getElementById('gender');
    let ageDiv = document.getElementById('age');
    let sentimentDiv = document.getElementById('sentiment');
    if (onOffWebCamButton.alt === "webcam off") {
        faceRecognition().then(onWebcam);
        video.style.backgroundColor = 'none';
        onOffWebCamButton.src = "./image/webcam-on.webp";
        onOffWebCamButton.alt = "webcam on";
        hands.onResults(onResultsHands);
    } else {
        offWebcam();
        video.style.backgroundColor = 'black';
        onOffWebCamButton.src = "./image/webcam-off.webp";
        onOffWebCamButton.alt = "webcam off"
        genderDiv.innerHTML = "GENDER";
        ageDiv.innerHTML = "AGE";
        sentimentDiv.innerHTML = "SENTIMENT";
        let img = document.getElementsByClassName('gallery-image');
        for (let i = 0; i < img.length; i++)
            img[i].style.display = 'block';
    }
}

function onWebcam() {
    camera.start();
}

function offWebcam() {
    let video = document.getElementById('video');
    let stream = video.srcObject;
    let tracks = stream.getTracks();
    for (let i = 0; i < tracks.length; i++) {
        let track = tracks[i];
        track.stop();
    }
    let display = document.getElementsByClassName('display-image-text');
    for (i = 1; i < imageData.length; i++) {
        display[i-1].style.opacity = 1;
    }

}

/*start HANDS-MEDIAPIPE*/

function onResultsHands(frame) {
    canvasContext.save();
    canvasContext.clearRect(0, 0, canvas.width, canvas.height);
    canvasContext.drawImage(canvas, 0, 0, canvas.width, canvas.height);
    if (frame.multiHandLandmarks && frame.multiHandedness) {
        const landmarks = frame.multiHandLandmarks[0];
        for (let i = 0; i < landmarks.length; i++) {
            if (i !== 8) {
                landmarks[i].x = -1;
                landmarks[i].y = -1;
            }
        }
        positionElement(landmarks);
        drawLandmarks(canvasContext, landmarks, {
            color: '#FF0000',
            lineWidth: 1,
            radius: (x) => {
                return lerp(x.from.z, -0.15, .1, 10, 1);
            }
        });

    }
    canvasContext.restore();
}

function positionElement(landmarks) {
    if (positionToggleSwitchButton.top / positionCanvas.height <= landmarks[8].y && landmarks[8].y <= positionToggleSwitchButton.bottom / positionCanvas.height &&
        positionToggleSwitchButton.left / positionCanvas.width <= landmarks[8].x && landmarks[8].y <= positionToggleSwitchButton.right / positionCanvas.width) {
        toggleSwitch();
    }else if (landmarks[8].y >= positionOnOffWebcamButton.top / positionCanvas.height && landmarks[8].y <= positionOnOffWebcamButton.bottom / positionCanvas.height &&
        landmarks[8].x >= positionOnOffWebcamButton.left / positionCanvas.width && landmarks[8].x <= positionOnOffWebcamButton.right / positionCanvas.width) {
        onOffWebcam();
    }else if (positionSearchButton.top / positionCanvas.height <= landmarks[8].y && landmarks[8].y <= positionSearchButton.bottom / positionCanvas.height &&
        positionSearchButton.left / positionCanvas.width <= landmarks[8].x && landmarks[8].x <= positionSearchButton.right / positionCanvas.width) {
        detectFace();
    }
}

/*end HANDS-MEDIAPIPE*/

/*start FACE API LIBRARY*/

var age = 0;
var gender = '';
var sentiment = '';

async function faceRecognition() {
    const MODEL_URL = 'faceApi/models';

    await Promise.all([
        faceapi.loadSsdMobilenetv1Model(MODEL_URL),
        faceapi.loadFaceLandmarkModel(MODEL_URL),
        faceapi.loadFaceRecognitionModel(MODEL_URL),
        faceapi.loadFaceExpressionModel(MODEL_URL),
        faceapi.loadAgeGenderModel(MODEL_URL),
    ]);
}

async function detectFace() {
    const video = document.getElementById('video');
    const detectionResult = await faceapi.detectSingleFace(video).withFaceExpressions().withAgeAndGender();
    const displaySize = {width: 568, height: 475};
    const resizeDetection = faceapi.resizeResults(detectionResult, displaySize);
    if (detectionResult) {
        age = Math.round(resizeDetection.age);
        gender = resizeDetection.gender;
        const valueVect = resizeDetection.expressions;
        const maxValue = Math.max(...Object.values(valueVect));
        sentiment = Object.keys(valueVect).filter(expr => valueVect[expr] === maxValue);
        printData();
    }
}

function printData() {
    let genderDiv = document.getElementById('gender');
    let ageDiv = document.getElementById('age');
    let sentimentDiv = document.getElementById('sentiment');
    genderDiv.innerHTML = gender.toUpperCase();
    ageDiv.innerHTML = age;
    sentimentDiv.innerHTML = (sentiment.toString()).toUpperCase();
    selectImage();
}

/*end FACE API LIBRARY*/

function selectImage() {
    let display = document.getElementsByClassName('display-image-text');
    let genderArt = gender;
    let ageArt = age;
    let sentimentArt = sentiment;
    if (genderArt === "") {
        for (var i = 1; i < imageData.length; i++) {
            display[i-1].style.opacity = 1;
        }
    } else if (genderArt === "male") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].gender === "male") {
                display[i-1].style.opacity = 1;
            } else {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (genderArt === "female") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].gender === "female") {
                display[i-1].style.opacity = 1;
            } else {
                display[i-1].style.opacity = 0.2;
            }
        }
    }

    if (ageArt<30) {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i-1].age>30) {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (ageArt>=30 && ageArt<60) {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].age>60 || imageData[i].age<30) {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (ageArt>=60) {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].age<60) {
                display[i-1].style.opacity = 0.2;
            }
        }
    }

    if (sentimentArt[0] === "happy") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "happy") {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (sentimentArt[0] === "angry") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "angry") {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (sentimentArt[0] === "sad") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "sad") {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (sentimentArt[0] === "neutral") {
        for (i = 1; i <= imageData.length; i++) {
            if (imageData[i].sentiment !== "neutral") {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (sentimentArt[0] === "surprised") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "surprised") {
                display[i-1].style.opacity = 0.2;
            }
        }
    }
    else if (sentiment === "fearful") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "fearful") {
                display[i-1].style.opacity = 0.2;
            }
        }
    }
    else if (sentiment === "disgusted") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "disgusted") {
                display[i-1].style.opacity = 0.2;
            }
        }
    }
}

/*end LEFT SIDE*/