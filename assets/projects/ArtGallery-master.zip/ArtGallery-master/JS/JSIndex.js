const d = new Date();
const hour = d.getHours();
const month = d.getMonth();

function getHour() {
    if (month > 1 && month < 8) {
        if (hour > 6 && hour <= 12) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good morning');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        } else if (hour > 12 && hour <= 18.30) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good afternoon');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        } else if (hour > 18.30 && hour <= 21) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good evening');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        } else if (hour > 21 && hour <= 6) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good night');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        }
    } else if (month <= 1 || month >= 8) {
        if (hour > 7 && hour <= 12) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good morning');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        } else if (hour > 12 && hour <= 16.30) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good afternoon');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        } else if (hour > 16.30 && hour <= 21) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good evening');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        } else if (hour > 21 && hour <=23 || hour >=0 || hour <= 7) {
            const node = document.createElement('h1');
            const textNode = document.createTextNode('Good night');
            node.appendChild(textNode);
            document.getElementById('welcome-container').insertBefore(node, document.getElementById('welcome-text'));
        }
    }
}