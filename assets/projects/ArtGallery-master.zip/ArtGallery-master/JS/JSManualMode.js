function toggleSwitch() {
    if (document.getElementById("slider")) {
        document.location.href = 'webcamMode.php';
    }
}

var imageData = [];

class Image {
    constructor(gender, age, sentiment) {
        this.gender = gender;
        this.age = age
        this.sentiment = sentiment;
    }
}

function newImage(id, gender, age, sentiment) {
    imageData[id] = new Image(gender, age, sentiment);
}

function selectImage() {
    let display = document.getElementsByClassName('display-image-text');
    let gender = document.getElementById("genders").value;
    let age = document.getElementById("ages").value;
    let sentiment = document.getElementById("sentiments").value;
    if (gender === "") {
        for (var i = 1; i < imageData.length; i++) {
            display[i-1].style.opacity = 1;
        }
    } else if (gender === "male") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].gender === "male") {
                display[i-1].style.opacity = 1;
            } else {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (gender === "female") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].gender === "female") {
                display[i-1].style.opacity = 1;
            } else {
                display[i-1].style.opacity = 0.2;
            }
        }
    }

    if (age==='young') {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].age>30) {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (age==='adult') {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].age>60 || imageData[i].age<30) {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (age==='old') {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].age<60) {
                display[i-1].style.opacity = 0.2;
            }
        }
    }

    if (sentiment === "happy") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "happy") {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (sentiment === "angry") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "angry") {
                display[i-1].style.opacity = 0.2;
            }
        }
    } else if (sentiment === "sad") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "sad") {
                display[i-1].style.opacity = 0.2;
            }
        }
    }
    else if (sentiment === "surprised") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "surprised") {
                display[i-1].style.opacity = 0.2;
            }
        }
    }
    else if (sentiment === "fearful") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "fearful") {
                display[i-1].style.opacity = 0.2;
            }
        }
    }
    else if (sentiment === "neutral") {
        for (i = 1; i < imageData.length; i++) {
            if (imageData[i].sentiment !== "neutral") {
                display[i-1].style.opacity = 0.2;
            }
        }
    }
}


/*start IMAGE-EFFECT*/

function maxWidthImage(img){
    var containerImage = document.getElementById('max-width-img');
    if (window.getComputedStyle(containerImage).visibility === "hidden") {
        window.getComputedStyle(containerImage).display = 'block';
    }
    var image = document.getElementById(img);
    var maxImage = document.getElementById('max-width-img');
    var textBox = document.getElementById("description" );
    containerImage.style.display = 'block';
    maxImage.src = image.src;
    textBox.innerHTML = image.alt;
}

function closeImage() {
    var maxImage = document.getElementById('max-width-img');
    maxImage.style.display = "none";
}

/*end IMAGE-EFFECT*/







