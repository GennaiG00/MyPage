<!DOCTYPE html>
<html lang="en">
<head>
    <title>ArtGallery</title>
    <link rel="stylesheet" href="CSS/styleLoadImage.css" type="text/css">
    <link rel="stylesheet" href="CSS/generalStyle.css" type="text/css">
    <meta charset="UTF-8">
    <meta name="author" content="Gian Maria Gennai">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="faceApi/javascript/face-api.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
</head>
<body>
<div id="loadNewImage-container">
    <div id="header">
        <div id="title">
            <a href="index.html"><img id="title-image" src="image/logo-Model.webp"></a>
        </div>
    </div>
    <div id="update-container">
        <h4>This is a container for load another image on grid.</h4>
        <img id="loading-gif" src="image/loading.gif" alt="Wait">
        <form id="form-upload" name="form" action="loadNewImage.php" method="post">
            <label class="label-upload" for="image-name">Image Name</label>
            <input class="input-upload" type="text" id="iname" name="iname"><br>
            <label class="label-upload" for="lname">File Name</label>
            <input class="input-upload" type="text" id="fname" name="fname"><br>
            <p><input id="button-upload" type="submit" value="Search"/></p>
        </form>
        <button id="button-db-upload" onclick="dbUpload()">Load</button>
    </div>
    <button class="back-button" style="float: left" onclick="document.location.href = 'manualMode.php'">Back to Manual</button>
    <button class="back-button" style="float: right" onclick="document.location.href = 'webcamMode.php'">Back to Webcam</button>
</div>
</body>
</html>
<script>
    <?php if($_POST['iname']){ ?>
        if(document.getElementById('upload-image')){
            document.getElementById('form-upload').removeChild(document.getElementById('upload-image'));
        }
        var img = new Image();
        img.src = "image/" + "<?php echo $_POST['fname'] ?>";
        document.getElementById('form-upload').innerHTML += '<img id="upload-image" alt="<?php echo $_POST['fname'] ?>" name="<?php echo $_POST['iname'] ?>" src="'+img.src+'" />' ;
    <?php }?>

    function dbUpload(){
        document.getElementById('loading-gif').style.display = "block";
        faceRecognition().then(detectImageFace);
    }



    async function faceRecognition() {
        const MODEL_URL = 'faceApi/models';

        await Promise.all(  [
            faceapi.loadSsdMobilenetv1Model(MODEL_URL),
            faceapi.loadFaceLandmarkModel(MODEL_URL),
            faceapi.loadFaceRecognitionModel(MODEL_URL),
            faceapi.loadFaceExpressionModel(MODEL_URL),
            faceapi.loadAgeGenderModel(MODEL_URL),
        ]);
    }

    async function detectImageFace() {
        const img = document.getElementById('upload-image');
        const detectionResult = await faceapi.detectSingleFace(img).withFaceExpressions().withAgeAndGender();
        if (detectionResult) {
            const imageSize = {
                width: img.getBoundingClientRect().width,
                height: img.getBoundingClientRect().height
            };
            const resizeDetection = faceapi.resizeResults(detectionResult, imageSize);
            age = Math.round(resizeDetection.age);
            gender = resizeDetection.gender;
            const valueVect = resizeDetection.expressions;
            const maxValue = Math.max(...Object.values(valueVect));
            sentiment = Object.keys(valueVect).filter(expr => valueVect[expr] === maxValue);
            passDataToDatabase(img.alt,img.name, gender, age, sentiment[0]);
        }else{
            passDataToDatabase(img.alt,img.name,"", 0, "");
        }
        document.getElementById('loading-gif').style.display = 'none';
    }

    function passDataToDatabase(fname ,iname ,gender ,age ,sentiment){
        if(document.getElementById('upload-image')){
            document.getElementById('form-upload').removeChild(document.getElementById('upload-image'));
        }
        $.ajax({
            type: "POST",
            url: "db_connection.php",
            data: {
                fname: fname,
                iname: iname,
                gender: gender,
                age: age,
                sentiment: sentiment
            },
            cache: false,
            success: function(data) {
                // alert(data);
            },
            error: function(xhr, status, error) {
                console.error(xhr);
            }
        });
    }
</script>

