<!DOCTYPE html>
<html lang="en">
<head>
    <title>ArtGallery</title>
    <link rel="stylesheet" href="CSS/styleManualMode.css" type="text/css">
    <link rel="stylesheet" href="CSS/generalStyle.css" type="text/css">
    <meta charset="UTF-8">
    <meta name="author" content="Gian Maria Gennai">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script src="JS/JSManualMode.js"></script>
</head>
<body>
<div id="main-class">
    <div id="header">
        <div id="title">
            <a href="index.html"><img id="title-image" src="image/logo-Model.webp"></a>
        </div>
    </div>
    <div id="primary-main">
        <h3>Choose your search method with the toggle switch button and click on RELOAD.</h3>
        <div id="toggle-switch">
            <label id="switch">
                <input type="checkbox">
                <button id="slider" onclick="toggleSwitch()"></button>
            </label>
        </div>
        <p>This is <span id="span-text-mode">Manual Mode</span> click and choose the Gender, Age and Sentiment.
            After
            click on Search to see the result.</p>
    </div>
    <div id="container">
        <div id="left-side-body">
            <div id="menu">
                <div class="container-dropdown">
                    <label for="genders">Gender:</label>
                    <select name="genders" id="genders" class="dropdownMenu">
                        <option value=""></option>
                        <option value="male">Male</option>
                        <option value="female">Female</option>
                    </select>
                </div>
                <div class="container-dropdown">
                    <label for="ages">Age:</label>
                    <select name="ages" id="ages" class="dropdownMenu">
                        <option value=""></option>
                        <option value="young">Young</option>
                        <option value="adult">Adult</option>
                        <option value="old">Old</option>
                    </select>
                </div>
                <div class="container-dropdown">
                    <label for="sentiments">Sentiment:</label>
                    <select name="sentiments" id="sentiments" class="dropdownMenu">
                        <option value=""></option>
                        <option value="happy">Happy</option>
                        <option value="sad">Sad</option>
                        <option value="angry">Angry</option>
                        <option value="surprised">Surprised</option>
                        <option value="fearful">Fearful</option>
                        <option value="neutral">Neutral</option>
                    </select>
                </div>
                <div id="search">
                    <button id="search-button" onclick="selectImage()">Search</button>
                </div>
            </div>
        </div>
        <div id="right-side-body">
            <?php
            include "dbConnectionClass.php";
            $mysqli = new db('localhost', 'artgallery', 'artgallery', 'artgallery');
            $sql = "SELECT * FROM gallery";
            $resultTmp = $mysqli->query($sql)->fetchAll();
            for($j=0; $j<count($resultTmp); $j++){
                $result[$j+1] = $resultTmp[$j];
            }
            $numberOfTableRow = (count($result))+1;
            $numberOfGridRow = floor($numberOfTableRow / 4);
            $remainderNumber = $numberOfTableRow % 4;
            $i = 1;
            $a = 0;
            $b = 0;
            $c = 0;
            if ($remainderNumber === 1) {
                $a = 1;
            } elseif ($remainderNumber === 2) {
                $a = 1;
                $b = 1;
            } elseif ($remainderNumber === 3) {
                $a = 1;
                $b = 1;
                $c = 1;
            }
            ?>
            <div id="box-image">
                <div id="row">
                    <div class="column" id="first-column">
                        <?php
                        for (; $i <= $numberOfGridRow + $a; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text" onclick="maxWidthImage(<?php echo $result[$i]['id']; ?>)">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="column" id="second-column">
                        <?php
                        for (; $i <= ($numberOfGridRow * 2) + $a + $b; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="column" id="third-column">
                        <?php
                        for (; $i <= ($numberOfGridRow * 3) + $a + $b + $c; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="column" id="fourth-column">
                        <?php
                        for (; $i < ($numberOfGridRow * 4) + $a + $b + $c; $i++) {
                            $imageURL = 'image/' . $result[$i]['image'];
                            ?>
                            <div class="display-image-text">
                                <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                                     alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage('<?php echo $result[$i]['id'] ?>','<?php echo $result[$i]['gender']?>', <?php echo $result[$i]['age'] ?>, '<?php echo $result[$i]['sentiment'] ?>')">
                                <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                            </div>
                        <?php } ?>
                    </div>
                </div>
            </div>
            <div id="load-image">
                <button id="load-image-button" onclick="document.location.href = 'loadNewImage.php'">New Image</button>
            </div>
        </div>
    </div>
</div>
<div id="max-width">
    <span class="close" onclick="closeImage()">&times;</span>
    <img class="max-width-img">
    <div id="description"></div>
</div>
<?php

include 'footer.html';

?>
</body>
</html>