<?php
include "dbConnectionClass.php";
$mysqli = new db('localhost', 'artgallery', 'artgallery', 'artgallery');
$sql = "SELECT * FROM gallery";
$result = $mysqli->query($sql)->fetchAll();
$numberOfTableRow = (count($result));
$numberOfGridRow = ceil($numberOfTableRow / 4) - 1;
$remainderNumber = $numberOfTableRow % 4;
$i = 0;
$a = 0;
$b = 0;
$c = 0;
if ($remainderNumber === 1) {
    $a = 1;
} elseif ($remainderNumber === 2) {
    $a = 1;
    $b = 1;
} elseif ($remainderNumber === 3) {
    $a = 1;
    $b = 1;
    $c = 1;
}
?>
<div id="box-image">
    <div id="row">
        <div class="column" id="first-column">
            <?php
            for (; $i < $numberOfGridRow + $a; $i++) {
                $imageURL = 'image/' . $result[$i]['image'];
                ?>
                <div class="display-image-text">
                    <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                         alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>" onload="newImage(<?php echo $result[$i]['id'] ?>,<?php echo $result[$i]['gender']?>, <?php echo $result[$i]['age'] ?>, <?php echo $result[$i]['sentiment'] ?>)">
                    <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                </div>
            <?php } ?>
        </div>
        <div class="column" id="second-column">
            <?php
            for (; $i < ($numberOfGridRow * 2) + 1 + $b; $i++) {
                $imageURL = 'image/' . $result[$i]['image'];
                ?>
                <div class="display-image-text">
                    <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                         alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>">
                    <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                </div>
            <?php } ?>
        </div>
        <div class="column" id="third-column">
            <?php
            for (; $i < ($numberOfGridRow * 3) + 1 + $c; $i++) {
                $imageURL = 'image/' . $result[$i]['image'];
                ?>
                <div class="display-image-text">
                    <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                         alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>">
                    <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                </div>
            <?php } ?>
        </div>
        <div class="column" id="fourth-column">
            <?php
            for (; $i < ($numberOfGridRow * 4) + 1; $i++) {
                $imageURL = 'image/' . $result[$i]['image'];
                ?>
                <div class="display-image-text">
                    <img class="gallery-image" id="<?php echo $result[$i]['id']; ?>"
                         alt="<?php echo $result[$i]['name']; ?>" src="<?php echo $imageURL ?>">
                    <div class="image-text"><?php echo $result[$i]['name'] ?></div>
                </div>
            <?php } ?>
        </div>
    </div>
</div>
<div id="load-image">
    <button id="load-image-button" onclick="document.location.href = 'loadNewImage.php'">New Image</button>
</div>